// background.js — Manifest V3 service worker.
// Centralizes all calls to the AI API so the API key never needs to
// live in the content script's page context. Handles two jobs:
//   1. PARSE_RESUME   — turn raw resume text into structured JSON
//   2. MAP_FIELDS     — given a batch of unmatched form field labels and
//                        the resume JSON, ask the model for best-fit values
//
// Uses Groq (console.groq.com) by default — a free-tier, no-credit-card-
// required API that speaks the same request/response format as OpenAI's
// chat completions endpoint. The chat model itself is auto-discovered per
// account (see resolveModel below) rather than hardcoded, since Groq's
// available model set varies by account and changes over time.

const API_BASE = "https://api.groq.com/openai/v1";
const CHAT_URL = `${API_BASE}/chat/completions`;
const MODELS_URL = `${API_BASE}/models`;

// Preference order — first of these that's actually enabled on the
// current API key/account is used. Auto-discovered instead of hardcoded
// because Groq's available model set varies by account (verification
// tier, region, retirements) and changes over time.
const MODEL_PREFERENCE = [
  "llama-3.3-70b-versatile",
  "openai/gpt-oss-120b",
  "openai/gpt-oss-20b",
  "llama-3.1-8b-instant",
  "meta-llama/llama-4-scout-17b-16e-instruct",
  "qwen/qwen3-32b",
];

let resolvedModel = null; // cached for this service worker's lifetime

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.type === "PARSE_RESUME") {
    handleParseResume(message.payload.rawText)
      .then((data) => sendResponse({ ok: true, data }))
      .catch((err) => sendResponse({ ok: false, error: err.message }));
    return true; // keep the message channel open for the async response
  }

  if (message.type === "MAP_FIELDS") {
    handleMapFields(message.payload.fields, message.payload.resumeProfile, message.payload.apiKey)
      .then((data) => sendResponse({ ok: true, data }))
      .catch((err) => sendResponse({ ok: false, error: err.message }));
    return true;
  }
});

async function getApiKey() {
  const { groqApiKey } = await chrome.storage.local.get("groqApiKey");
  if (!groqApiKey) throw new Error("No Groq API key saved.");
  return groqApiKey;
}

async function resolveModel(apiKey, forceRefresh = false) {
  if (resolvedModel && !forceRefresh) return resolvedModel;

  const res = await fetch(MODELS_URL, {
    headers: { Authorization: `Bearer ${apiKey}` },
  });
  if (!res.ok) {
    // Can't even list models — fall back to the first preference and let
    // the chat call itself surface a clear error.
    resolvedModel = MODEL_PREFERENCE[0];
    return resolvedModel;
  }
  const data = await res.json();
  const availableIds = new Set((data.data || []).map((m) => m.id));

  const preferred = MODEL_PREFERENCE.find((id) => availableIds.has(id));
  if (preferred) {
    resolvedModel = preferred;
    return resolvedModel;
  }

  // None of our preferred IDs are available — pick any active chat model
  // (skip Whisper/audio and Guard/moderation models, which can't do this task).
  const fallback = (data.data || []).find(
    (m) => !/whisper|guard/i.test(m.id)
  );
  if (!fallback) throw new Error("No usable chat model is enabled on this Groq account.");
  resolvedModel = fallback.id;
  return resolvedModel;
}

async function callAI(apiKey, systemPrompt, userPrompt, retrying = false) {
  const model = await resolveModel(apiKey, retrying);
  const res = await fetch(CHAT_URL, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${apiKey}`,
    },
    body: JSON.stringify({
      model,
      temperature: 0,
      response_format: { type: "json_object" },
      messages: [
        { role: "system", content: systemPrompt },
        { role: "user", content: userPrompt },
      ],
    }),
  });

  if (!res.ok) {
    const errBody = await res.text();
    // If the resolved model itself turned out to be unavailable, refresh
    // the model list once and retry with whatever else is available.
    if (res.status === 404 && !retrying) {
      resolvedModel = null;
      return callAI(apiKey, systemPrompt, userPrompt, true);
    }
    throw new Error(`Groq API error ${res.status}: ${errBody.slice(0, 300)}`);
  }
  const data = await res.json();
  const content = data.choices?.[0]?.message?.content;
  if (!content) throw new Error("Empty response from Groq.");
  return JSON.parse(content);
}

async function handleParseResume(rawText) {
  const apiKey = await getApiKey();
  const systemPrompt = `You convert unstructured resume text into a strict JSON object describing a candidate.
Return ONLY valid JSON matching this shape (omit a field only if truly absent, use null instead of guessing wildly):
{
  "fullName": string, "firstName": string, "lastName": string,
  "email": string, "phone": string, "location": {"city": string, "state": string, "country": string},
  "linkedin": string, "github": string, "portfolio": string,
  "summary": string,
  "workExperience": [{"company": string, "title": string, "startDate": string, "endDate": string, "current": boolean, "location": string, "description": string}],
  "education": [{"school": string, "degree": string, "fieldOfStudy": string, "startDate": string, "endDate": string, "gpa": string}],
  "skills": [string],
  "certifications": [string],
  "yearsOfExperience": number
}
Infer missing structured fields (e.g. split full name, compute yearsOfExperience from work history) but never invent employers, schools, or dates that are not supported by the text.`;

  return callAI(apiKey, systemPrompt, `Resume text:\n"""\n${rawText}\n"""`);
}

async function handleMapFields(fields, resumeProfile, apiKeyOverride) {
  const apiKey = apiKeyOverride || (await getApiKey());
  const systemPrompt = `You fill job-application form fields from a candidate's resume profile (JSON) plus a list of
form fields (each with a label, field type, and optional options list for dropdowns/radios/checkboxes).
For each field, return your best-fit answer using the candidate's real data. Never fabricate employers, dates,
or credentials that are not implied by the profile. For EEO/voluntary-disclosure style questions (race, gender,
veteran status, disability) about which the profile has no information, respond with "DECLINE" so the extension
leaves that field to the human. For a dropdown/radio/checkbox field, choose the closest matching value from
"options" verbatim, or "DECLINE" if none is a confident fit.
Return ONLY valid JSON: {"answers": [{"fieldId": string, "value": string, "confidence": number}]}`;

  const userPrompt = JSON.stringify({ resumeProfile, fields });
  return callAI(apiKey, systemPrompt, userPrompt);
}
