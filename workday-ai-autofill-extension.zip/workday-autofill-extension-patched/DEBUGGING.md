# Workday AI Autofill — Fix Notes

## What was fixed

1. **Field discovery was too wrapper-dependent.**
   The old scanner started from `formField-*` wrappers. The new scanner starts
   from actual inputs/selects/textareas/comboboxes and then finds their nearest
   Workday wrapper. This handles tenants where the wrapper structure differs.

2. **Label discovery was fragile.**
   The new scanner checks, in order:
   - `label[for]`
   - `aria-label`
   - `aria-labelledby`
   - Workday wrapper labels/rich text
   - nearby text as a last resort.

3. **React-controlled inputs could visually change but not retain state.**
   The filler now uses the native input/textarea value setter, dispatches
   `InputEvent("input")`, then `change` and blur, and verifies the resulting
   value with one retry.

4. **Radio/checkbox labels were searched only inside the wrapper.**
   The new code also resolves labels globally by `for="..."`.

5. **The DOM settle logic was too easy to race.**
   The observer now waits longer for a quiet period and the navigation path
   waits for the next render before scanning again.

6. **Better diagnostics.**
   Open the Workday page's DevTools Console and look for:
   `[Workday Autofill] scanned fields:`
   and
   `[Workday Autofill] filled:`

## Important limitation

Workday custom combobox/search widgets are intentionally left for manual entry
when the extension cannot safely determine their state. File upload inputs also
remain manual because browsers do not permit arbitrary script assignment of a
file input's value.

## How to test

1. Remove/reload the old unpacked extension in `chrome://extensions`.
2. Load this fixed folder as an unpacked extension.
3. Refresh the Workday application tab.
4. Parse the resume again if needed.
5. Start Autofill.
6. Open DevTools -> Console and verify the scanner logs the expected fields.

If a particular field still does not fill, copy the `scanned fields` console
object and the exact Workday field label; that identifies whether the remaining
problem is detection, mapping, or filling.
