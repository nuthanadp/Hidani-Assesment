// Runs in the Workday page's MAIN world so React/Workday sees the same
// native DOM prototypes used by the application itself.
(function () {
  'use strict';
  if (window.__WF_AUTOFILL_PAGE_BRIDGE__) return;
  window.__WF_AUTOFILL_PAGE_BRIDGE__ = true;

  const normalizeId = (v) => String(v || '').replace(/[^a-zA-Z0-9_-]/g, '');

  function getTarget(id) {
    const safe = normalizeId(id);
    if (!safe) return null;
    return document.querySelector(`[data-wf-autofill-id="${CSS.escape(safe)}"]`);
  }

  function setReactValue(el, value) {
    if (!el) return false;
    const tag = el.tagName.toUpperCase();
    const proto = tag === 'TEXTAREA'
      ? window.HTMLTextAreaElement.prototype
      : window.HTMLInputElement.prototype;
    const descriptor = Object.getOwnPropertyDescriptor(proto, 'value');
    const setter = descriptor && descriptor.set;
    if (!setter) return false;

    const oldValue = String(el.value || '');
    try { el.focus(); } catch (_) {}

    // Reset React's value tracker to the value it believed was present before
    // our native setter runs. This makes the following input event look like a
    // real user edit to controlled React inputs.
    try {
      const tracker = el._valueTracker;
      if (tracker && typeof tracker.setValue === 'function') tracker.setValue(oldValue);
    } catch (_) {}

    try {
      el.dispatchEvent(new InputEvent('beforeinput', {
        bubbles: true,
        cancelable: true,
        inputType: 'deleteContentBackward',
        data: null
      }));
    } catch (_) {}

    setter.call(el, '');
    el.dispatchEvent(new InputEvent('input', {
      bubbles: true,
      inputType: 'deleteContentBackward',
      data: null
    }));

    // Set the complete value through the page-world native setter.
    setter.call(el, String(value));
    try {
      el.dispatchEvent(new InputEvent('beforeinput', {
        bubbles: true,
        cancelable: true,
        inputType: 'insertText',
        data: String(value)
      }));
    } catch (_) {}
    el.dispatchEvent(new InputEvent('input', {
      bubbles: true,
      inputType: 'insertText',
      data: String(value)
    }));
    el.dispatchEvent(new Event('change', { bubbles: true }));

    // Workday validation commonly commits controlled fields on focusout.
    // Explicitly emit both focusout and blur after the value has been changed.
    el.dispatchEvent(new FocusEvent('focusout', { bubbles: true }));
    el.dispatchEvent(new FocusEvent('blur', { bubbles: false }));
    try { el.blur(); } catch (_) {}

    return String(el.value || '').trim() === String(value).trim();
  }

  window.postMessage({ source: 'WF_AUTOFILL_PAGE', type: 'WF_BRIDGE_READY' }, '*');

  window.addEventListener('message', (event) => {
    if (event.source !== window) return;
    const data = event.data;
    if (!data || data.source !== 'WF_AUTOFILL_CONTENT') return;

    if (data.type === 'WF_SET_REACT_VALUE') {
      const el = getTarget(data.id);
      const ok = setReactValue(el, data.value);
      window.postMessage({
        source: 'WF_AUTOFILL_PAGE',
        type: 'WF_SET_REACT_VALUE_RESULT',
        id: data.id,
        ok
      }, '*');
    }
  });
})();
