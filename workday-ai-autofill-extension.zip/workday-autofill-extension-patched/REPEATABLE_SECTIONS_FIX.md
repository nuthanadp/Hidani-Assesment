# Repeatable Workday Sections Fix

The Workday "My Experience" page shown in testing has **Work Experience** and
**Education** represented by `Add` buttons, not by input controls.

The previous implementation scanned inputs first and then attempted to identify
Add buttons by requiring the button's own text/aria-label to contain the word
"experience" or "education". In this Workday layout the button text is simply
`Add`, so it was ignored. The navigator then clicked Save and Continue.

The new implementation:

- Detects `Add` buttons by their relationship to the nearest Work Experience
  or Education heading.
- Clicks Add before navigating to the next step.
- Waits for new controls to actually appear.
- Fills each newly created entry from the corresponding resume record.
- Sends only that individual record to the AI mapper for unresolved fields.
- If Add cannot be detected or the new entry does not open, it **pauses**.
- If a step has no recognizable fields, it **pauses instead of skipping**.
- Checks Workday validation errors before clicking Next.
- Retains the no-loop guard if Next does not actually advance.

This prevents the extension from silently skipping Work Experience/Education.
