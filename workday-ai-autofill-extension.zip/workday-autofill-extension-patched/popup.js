// popup.js — runs in the extension popup context.
// Responsibilities: manage the (free) Groq API key, extract raw text from
// an uploaded PDF/DOCX resume, ask the background service worker to turn
// that text into structured JSON via the Groq API, and kick off autofill
// on the active Workday tab.

const apiKeyInput = document.getElementById("apiKey");
const saveKeyBtn = document.getElementById("saveKeyBtn");
const keyStatus = document.getElementById("keyStatus");

const resumeFileInput = document.getElementById("resumeFile");
const parseBtn = document.getElementById("parseBtn");
const parseStatus = document.getElementById("parseStatus");
const resumePreview = document.getElementById("resumePreview");
const resumeJsonEl = document.getElementById("resumeJson");

const autofillBtn = document.getElementById("autofillBtn");
const runStatus = document.getElementById("runStatus");

let rawResumeText = null;

// ---------- init ----------
(async function init() {
  const { groqApiKey, resumeProfile } = await chrome.storage.local.get([
    "groqApiKey",
    "resumeProfile",
  ]);
  if (groqApiKey) {
    apiKeyInput.value = groqApiKey;
    setStatus(keyStatus, "Key loaded from storage.", "ok");
  }
  if (resumeProfile) {
    showResumePreview(resumeProfile);
    autofillBtn.disabled = false;
  }
})();

// ---------- API key ----------
saveKeyBtn.addEventListener("click", async () => {
  const key = apiKeyInput.value.trim();
  if (!key) {
    setStatus(keyStatus, "Enter a key first.", "err");
    return;
  }
  await chrome.storage.local.set({ groqApiKey: key });
  setStatus(keyStatus, "Saved.", "ok");
});

// ---------- resume upload ----------
resumeFileInput.addEventListener("change", async () => {
  const file = resumeFileInput.files[0];
  parseStatus.textContent = "";
  parseBtn.disabled = true;
  rawResumeText = null;
  if (!file) return;

  try {
    setStatus(parseStatus, "Extracting text…", "");
    if (file.name.toLowerCase().endsWith(".pdf")) {
      rawResumeText = await extractPdfText(file);
    } else if (file.name.toLowerCase().endsWith(".docx")) {
      rawResumeText = await extractDocxText(file);
    } else {
      throw new Error("Unsupported file type. Use PDF or DOCX.");
    }
    setStatus(parseStatus, `Extracted ${rawResumeText.length} characters.`, "ok");
    parseBtn.disabled = false;
  } catch (err) {
    console.error(err);
    setStatus(parseStatus, "Extraction failed: " + err.message, "err");
  }
});

async function extractPdfText(file) {
  const arrayBuffer = await file.arrayBuffer();
  // pdf.js needs its worker script location.
  pdfjsLib.GlobalWorkerOptions.workerSrc = chrome.runtime.getURL("lib/pdf.worker.min.js");
  const pdf = await pdfjsLib.getDocument({ data: arrayBuffer }).promise;
  let text = "";
  for (let i = 1; i <= pdf.numPages; i++) {
    const page = await pdf.getPage(i);
    const content = await page.getTextContent();
    text += content.items.map((it) => it.str).join(" ") + "\n";
  }
  return text.trim();
}

async function extractDocxText(file) {
  const arrayBuffer = await file.arrayBuffer();
  const result = await mammoth.extractRawText({ arrayBuffer });
  return result.value.trim();
}

// ---------- AI parsing ----------
parseBtn.addEventListener("click", async () => {
  const { groqApiKey } = await chrome.storage.local.get("groqApiKey");
  if (!groqApiKey) {
    setStatus(parseStatus, "Save an Groq API key first.", "err");
    return;
  }
  if (!rawResumeText) {
    setStatus(parseStatus, "Upload a resume first.", "err");
    return;
  }

  parseBtn.disabled = true;
  setStatus(parseStatus, "Asking AI to structure the resume…", "");

  try {
    const response = await chrome.runtime.sendMessage({
      type: "PARSE_RESUME",
      payload: { rawText: rawResumeText },
    });
    if (!response || !response.ok) {
      throw new Error(response?.error || "Unknown error from background worker.");
    }
    await chrome.storage.local.set({ resumeProfile: response.data });
    showResumePreview(response.data);
    setStatus(parseStatus, "Resume parsed and saved.", "ok");
    autofillBtn.disabled = false;
  } catch (err) {
    console.error(err);
    setStatus(parseStatus, "Parsing failed: " + err.message, "err");
  } finally {
    parseBtn.disabled = false;
  }
});

function showResumePreview(profile) {
  resumePreview.classList.remove("hidden");
  resumeJsonEl.textContent = JSON.stringify(profile, null, 2);
}

// ---------- autofill trigger ----------
autofillBtn.addEventListener("click", async () => {
  runStatus.textContent = "";
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab || !/myworkdayjobs\.com|workday\.com/.test(tab.url || "")) {
    setStatus(runStatus, "Open a Workday application page first.", "err");
    return;
  }
  const { resumeProfile, groqApiKey } = await chrome.storage.local.get([
    "resumeProfile",
    "groqApiKey",
  ]);
  if (!resumeProfile) {
    setStatus(runStatus, "Parse a resume first.", "err");
    return;
  }

  try {
    await chrome.tabs.sendMessage(tab.id, {
      type: "START_AUTOFILL",
      payload: { resumeProfile, groqApiKey },
    });
    setStatus(runStatus, "Autofill started on the page — watch the tab.", "ok");
  } catch (err) {
    setStatus(
      runStatus,
      "Could not reach the page. Reload the Workday tab and try again.",
      "err"
    );
  }
});

function setStatus(el, text, cls) {
  el.textContent = text;
  el.className = "status" + (cls ? " " + cls : "");
}
