# Workday AI Autofill — Chrome Extension

An AI-assisted Chrome extension (Manifest V3) that parses a resume, then
navigates and fills a multi-step Workday job application, stopping at a
review screen for explicit human confirmation before any submission.

## Selected target application

Per the assignment's "Workday Company Scope" note, one posting was selected
for focused development and testing:

**NVIDIA — Senior Software Architect, Deep Learning and HPC Communications**
`https://nvidia.wd5.myworkdayjobs.com/en-US/NVIDIAExternalCareerSite/details/Senior-Software-Architect---Deep-Learning-and-HPC-Communications_JR2016116`

The field-scanning logic is written against Workday's generic
`data-automation-id="formField-*"` DOM convention rather than hardcoded
per-posting selectors, so it also runs against the other three sample
postings (NVIDIA DFT Engineer, Target ETL, Target Food & Beverage) with the
same code path — but the demo/testing focus is the NVIDIA posting above, as
required.

## Setup

1. **Get a free Groq API key** — go to [console.groq.com/keys](https://console.groq.com/keys),
   sign up (no credit card required), and create a key. Groq's free tier
   runs Llama 3.3 70B and is plenty for testing this extension. (To swap
   providers later — back to Groq, or Google AI Studio's free Gemini tier —
   only `API_URL` and `MODEL` at the top of `background.js` need to change;
   the prompt/response contract is isolated in `handleParseResume` and
   `handleMapFields`.)
2. **Load the extension:**
   - Open `chrome://extensions`
   - Enable "Developer mode" (top right)
   - Click "Load unpacked" and select this folder
3. **Open the extension popup**, paste your Groq API key, click **Save Key**.
4. **Upload your resume** (PDF or DOCX) and click **Parse Resume with AI** —
   this extracts raw text locally (via bundled `pdf.js` / `mammoth.js`) and
   sends only that text to Groq to get back structured JSON, shown in a
   preview pane.
5. **Navigate to the target Workday posting** and click "Apply".
6. Open the extension popup again and click **Autofill This Workday Page**.
7. Watch the page: the extension fills each step, clicks "Next", waits for
   the page to settle, and repeats. When it reaches the review/submit step
   it stops and shows an on-page banner — **it never clicks Submit for you**.

## Architecture

Four modules inside `content.js`, matching the assignment's required
breakdown:

| Module | Responsibility |
|---|---|
| **Parser** | Lives upstream, in `popup.js` + `background.js`. Extracts raw text from the uploaded PDF/DOCX client-side, then asks the Groq API to return structured resume JSON (name, contact info, work history, education, skills, links). |
| **FieldScanner** | Walks the current step's DOM, finds Workday's `formField-*` wrappers, pulls each field's visible label, and classifies its control type (text, textarea, select, radio, checkbox, date, or Workday's custom combobox widget). |
| **Mapper** | Tries a table of ~18 regex heuristics first (e.g. `/first\s*name/i` → `profile.firstName`) since these are free, instant, and deterministic. Anything left unmatched — including arbitrary custom/EEO questions — is batched and sent once per step to `MAP_FIELDS` in the background worker, which asks the model for a best-fit value or `"DECLINE"` when no confident answer exists. |
| **Filler** | Writes values back into the DOM using React-safe native setters (so Workday's internal state updates, not just the visible text) and dispatches `input`/`change`/`blur`. Handles native selects, radio/checkbox groups, and Workday's custom listbox/combobox by opening it and clicking the best-matching option. |
| **Navigator** (top-level loop in `content.js`) | Waits for the DOM to settle after each render (`MutationObserver`-based quiet-period detection) before scanning, so dynamically-rendered fields aren't missed. Attempts to expand repeatable sections (e.g. "Add Another Work Experience") to match the resume's actual number of entries. Finds and clicks the step's "Next" button, or stops and surfaces a review overlay once it detects a submit-style step. |

## AI integration & prompting

Two model calls, both constrained to `response_format: json_object` so
responses are directly parseable:

- **Resume → JSON** (`handleParseResume`): one call per uploaded resume.
  System prompt defines the exact JSON schema and explicitly forbids
  inventing employers/dates not present in the source text.
- **Field → value** (`handleMapFields`): one call per form step, batching
  every unmatched field's label/type/options together (rather than one call
  per field) to control latency and API cost. The prompt instructs the
  model to answer `"DECLINE"` for anything it can't confidently infer from
  the resume — this is what implements the assignment's requirement to
  leave EEO/voluntary-disclosure questions to the human rather than guessing.

Heuristics run first specifically so the AI is only invoked for the fields
that actually need semantic judgment, which keeps mapping fast and cheap on
straightforward steps (name/contact info) where deterministic rules are
just as accurate.

## Constraints honored

- **No authentication bypass** — the extension only acts after the user has
  manually logged in / created a candidate account; it never touches
  credential fields programmatically beyond normal autofill of visible text
  inputs the user has already reached.
- **Explicit confirmation before submission** — the Navigator loop
  hard-stops the moment it detects a submit-style step and never calls
  `.click()` on anything matching a submit button.
- **No hardcoded per-posting selectors** — all scanning is done via
  Workday's shared `data-automation-id="formField-*"` convention and visible
  label text, so it's resilient to layout differences between postings/tenants.
- **Sensitive data handling** — the Groq API key and parsed resume JSON
  are stored only in `chrome.storage.local` (never synced, never sent
  anywhere except directly to `api.openai.com` over HTTPS from the
  background worker).

## Automation strategy & anti-bot resilience

Testing during development surfaced a real-world issue not obvious from
the DOM alone: Workday's platform (observed consistently across two
unrelated tenants — NVIDIA's and Target's) appears to have some form of
automation/bot detection that can terminate the application session with
a generic "Something went wrong" error when it sees interaction patterns
that don't look like real typing — e.g. setting an input's value in one
shot and firing a single `input`/`change` pair, with no `keydown`/`keyup`
events at all. Real typing always produces a `keydown` → value change →
`keyup` sequence per character, with irregular human timing between them.

To work reliably against that, `typeIntoField()` simulates real typing:
for short fields (names, email, phone, city — the identity-sensitive
fields most likely to be watched) it dispatches an actual `keydown`,
updates the value by one character via the native setter, dispatches
`input`, then `keyup`, with a randomized 14–36ms delay between characters.
Longer free-text (summaries) is typed in small incremental chunks rather
than one instantaneous jump, for the same reason without taking forever.
An additional ~120ms pause between fields, and a longer settle time after
each step transition, further avoids interaction patterns that look
scripted rather than human.

## Known limitations

- **Focus/blur handling.** Text and select fields are filled using
  `el.focus()` / `el.blur()` (real DOM method calls that move the browser's
  actual focus state) rather than a synthetic `dispatchEvent(new
  Event("blur"))`, which does *not* move real focus. Firing a "blur" event
  without ever truly focusing the element leaves `document.activeElement`
  unchanged — an inconsistent state that broke Workday's own validation
  logic in early testing (surfaced as a generic "Something went wrong"
  Workday-side error). Values are also written via each element's native
  property setter (bypassing React's value-tracking shim) so Workday's
  controlled inputs register the change the same way they would for real
  typing.
- **File-upload fields** (e.g. attaching the résumé PDF itself inside the
  Workday form) are not auto-filled — browsers do not allow scripts to
  programmatically set a `<input type="file">`'s value for security reasons,
  so the user still needs to attach that file manually when Workday asks
  for it.
- **Workday's custom combobox/prompt widgets** (e.g. "How Did You Hear
  About Us?") vary a lot between tenants and sometimes open a search panel
  or modal rather than a plain dropdown. Earlier versions of this extension
  tried to click into them automatically — and separately, tried to flag
  them by inserting a small badge element into Workday's own DOM. Both
  turned out to be unsafe: clicking into an unfamiliar widget, and even
  just inserting extra nodes into a React-managed tree, can desync
  Workday's internal state and crash the page with a generic "Something
  went wrong" error. The extension now does neither — it never inserts,
  removes, or restyles any element inside Workday's own component tree.
  It only (a) writes values into real form controls via the same native
  setters/events a browser fires on real typing, (b) clicks real buttons
  Workday itself renders (Next, Add Another, etc.), and (c) appends its own
  toast/review-overlay elements as siblings of Workday's app, never inside
  it. Fields it can't confidently answer are listed with their suggested
  value in the on-page review overlay at the end, for you to fill by hand.
- **CAPTCHA / bot-detection steps**, if a given tenant has them, are out of
  scope and require the human to solve them — the extension simply pauses
  there since no "Next" button will be found.
- **Multi-language postings** — heuristics are English-only; the AI fallback
  will still generally work since the model can read other languages, but
  confidence is untested outside English postings.
- Tested against the DOM conventions Workday uses broadly; if the target
  tenant renders an atypical page (`formField-` wrappers absent) the scanner
  falls back to `fieldset`/`role=group` elements, which is less precise.

## Deliverables checklist

- [x] Source code (this folder / the provided ZIP)
- [x] Chrome extension build — load unpacked via `chrome://extensions` (see Setup)
- [x] Documentation — this file
- [ ] Demo video — record locally on your machine per your assessment's
      submission instructions: open the NVIDIA posting above, show resume
      upload + parse, click Autofill, let it run through the steps, then
      show the review-gate banner at the end without submitting.
