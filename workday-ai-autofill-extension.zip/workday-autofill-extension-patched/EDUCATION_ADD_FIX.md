# Education Add Fix

Education Add detection now prioritizes the exact visible `Add` control below the Education heading.
It does not rely on panelSetAddButton indexes, which can change after Work Experience is expanded.
