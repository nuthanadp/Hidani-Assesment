# Loop Fix

## Why the extension was looping

When an autofilled answer is incorrect, Workday can refuse the `Next` action and
leave the browser on the same application step. The old navigator only checked
whether a Next button existed. Because the button still existed, it clicked it
again and started another scan/fill cycle.

## What changed

The navigator now:

1. Captures a fingerprint of the current step.
2. Fills the fields.
3. Clicks Next once.
4. Waits for Workday to render/validate.
5. Captures the new fingerprint.
6. If the fingerprint is unchanged, it assumes the step was rejected and **stops**.
7. It also collects visible validation errors and prints them to the DevTools console.

This prevents repeated filling and gives you a chance to correct the rejected
field manually.

## Testing

Reload the unpacked extension, refresh the Workday page, and start Autofill.

If Workday rejects a value, the extension should now say:

`Workday rejected this step... Autofill paused.`

It should NOT click Next repeatedly.

The DevTools Console will show the validation messages when available.
