// content.js — injected into Workday application pages.
// Architecture (per assignment spec): Parser (upstream, in popup/background)
// -> FieldScanner -> Mapper (heuristics + AI fallback) -> Filler -> Navigator.
// Nothing here ever submits the application; the final step always waits
// for explicit human confirmation in an on-page review overlay.

(function () {
  "use strict";

  const STEP_SETTLE_MS = 1400; // wait for Workday's React re-render + backend save after navigation
  const MAX_STEPS = 25; // hard stop so a stuck loop can't run forever

  let resumeProfile = null;
  let groqApiKey = null;
  let running = false;
  let manualReviewItems = []; // {label, suggestion} — never written into Workday's own DOM
  let pageBridgeReady = false;
  let pageBridgeWaiters = [];

  // Workday uses React-controlled inputs. The visible DOM value can change while
  // React's internal form state remains empty. Load a tiny MAIN-world bridge so
  // the native value setter and events execute in the same JS world as Workday.
  function ensurePageBridge() {
    if (pageBridgeReady || document.documentElement?.dataset?.wfAutofillBridge === "ready") {
      pageBridgeReady = true;
      return Promise.resolve();
    }

    return new Promise((resolve) => {
      pageBridgeWaiters.push(resolve);
      const existing = document.querySelector('script[data-wf-autofill-bridge]');
      if (existing) return;

      const script = document.createElement("script");
      script.src = chrome.runtime.getURL("page-bridge.js");
      script.dataset.wfAutofillBridge = "true";
      script.onload = () => { script.remove(); };
      (document.head || document.documentElement).appendChild(script);
    });
  }

  window.addEventListener("message", (event) => {
    if (event.source !== window) return;
    const data = event.data;
    if (!data || data.source !== "WF_AUTOFILL_PAGE") return;
    if (data.type === "WF_BRIDGE_READY") {
      pageBridgeReady = true;
      const waiters = pageBridgeWaiters.splice(0);
      waiters.forEach(resolve => resolve());
      return;
    }
    if (data.type === "WF_SET_REACT_VALUE_RESULT") {
      pageBridgeReady = true;
    }
  });

  chrome.runtime.onMessage.addListener((message) => {
    if (message.type === "START_AUTOFILL") {
      resumeProfile = message.payload.resumeProfile;
      groqApiKey = message.payload.groqApiKey;
      if (!running) {
        running = true;
        runAutofillLoop().catch((err) => {
          console.error("[Workday Autofill] fatal error:", err);
          toast("Autofill stopped: " + err.message, "err");
          running = false;
        });
      }
    }
  });

  // ============================================================
  // Navigator — drives the multi-step Workday flow
  // ============================================================
  async function runAutofillLoop() {
    manualReviewItems = [];
    toast("Autofill started…", "info");

    for (let step = 0; step < MAX_STEPS; step++) {
      await waitForStableDom();

      if (isReviewOrSubmitStep()) {
        await showReviewGate();
        running = false;
        return;
      }

      // Workday's Work Experience/Education sections are NOT normal fields.
      // They start as an "Add" button. Handle those BEFORE considering Next.
      const repeatableResult = await handleRepeatableSections();
      if (repeatableResult.blocked) {
        running = false;
        return;
      }

      // Repeatable sections have already been filled record-by-record above.
      // Exclude their controls from the generic mapper so it cannot overwrite
      // entry #2/#3 with resumeProfile[0].
      const fields = FieldScanner.scan().filter(field => !isRepeatableField(field.element));
      if (fields.length === 0) {
        // Never silently skip a step. If we don't understand the page, give
        // the user control instead of clicking Next and losing required data.
        toast(
          "I could not identify the fields on this step. Autofill is paused so you can complete it manually.",
          "err"
        );
        running = false;
        return;
      }

      await Mapper.fillAll(fields);

      // IMPORTANT: Let Workday perform its own validation when Save and Continue
      // is clicked. Do not pre-block the navigation based on the DOM validation
      // state: Workday often marks required fields only after the user attempts
      // to continue. This gives the user the intended workflow: autofill first,
      // click Save and Continue once, then manually fix anything Workday flags.
      await sleep(500);

      const nextBtn = findNextButton();
      if (!nextBtn) {
        toast(
          "No further Next/Save and Continue button found. Autofill is paused for manual review.",
          "info"
        );
        running = false;
        return;
      }

      const beforeStep = getStepFingerprint();

      toast(`Step ${step + 1} completed. Moving to next step…`, "ok");
      nextBtn.scrollIntoView({ block: "center", behavior: "instant" });
      nextBtn.click();

      await waitForStableDom(700, 9000);
      await sleep(STEP_SETTLE_MS);

      const afterStep = getStepFingerprint();
      const validationErrors = getValidationErrors();

      if (beforeStep === afterStep) {
        console.warn("[Workday Autofill] Next did not advance.", {
          validationErrors,
          manualReviewItems,
        });

        if (validationErrors.length) {
          // Workday stayed on the same step because one or more fields failed
          // validation. This is an intentional hand-off to the user: Workday
          // has already displayed the missing/invalid-field errors, so the user
          // can fill those fields manually and then click Save and Continue.
          toast(
            `Workday found ${validationErrors.length} missing or invalid field(s). Please fill them manually, then click Save and Continue.`,
            "err"
          );
          console.table(validationErrors.map(message => ({
            WorkdayValidationError: message
          })));
        } else {
          toast(
            "The page did not advance after Save and Continue. Autofill paused to prevent a loop.",
            "err"
          );
        }

        running = false;
        return;
      }
    }

    toast("Reached the step limit — please continue manually.", "err");
    running = false;
  }

  // Creates a lightweight fingerprint for the current Workday step.
  // We intentionally use visible field labels + values + headings rather than
  // React/internal ids, because those ids can change after every render.
  function getStepFingerprint() {
    const fields = Array.from(document.querySelectorAll(
      'input:not([type="hidden"]), textarea, select, [role="combobox"], [role="listbox"]'
    ))
      .filter(isVisible)
      .map(el => {
        const label = getControlLabel(el);
        const value =
          el.tagName.toLowerCase() === "select"
            ? (el.options[el.selectedIndex]?.textContent || el.value || "")
            : (el.value || el.getAttribute("aria-valuetext") || "");
        return `${cleanLabel(label)}=${String(value).trim()}`;
      })
      .sort()
      .join("|");

    const heading = Array.from(document.querySelectorAll("h1,h2,h3"))
      .filter(isVisible)
      .map(h => cleanLabel(h.textContent))
      .join("|");

    return `${heading}::${fields}`;
  }

  function getValidationErrors() {
    const selectors = [
      '[aria-invalid="true"]',
      '[role="alert"]',
      '[data-automation-id*="error" i]',
      '.css-1wa3k2o', // some Workday tenants use generated error classes
    ];

    const nodes = [];
    for (const selector of selectors) {
      document.querySelectorAll(selector).forEach(el => {
        if (isVisible(el)) nodes.push(el);
      });
    }

    return [...new Set(
      nodes
        .map(el => cleanLabel(el.textContent || el.getAttribute("aria-label") || ""))
        .filter(Boolean)
    )].slice(0, 20);
  }

  function findNextButton() {
    const candidates = [
      '[data-automation-id="pageFooterNextButton"]',
      '[data-automation-id="bottom-navigation-next-button"]',
      'button[data-automation-id*="next" i]',
    ];
    for (const sel of candidates) {
      const el = document.querySelector(sel);
      if (el && !el.disabled) return el;
    }
    // Fallback: any visible button literally labelled "Next" or "Continue"
    const btns = Array.from(document.querySelectorAll("button"));
    return btns.find(
      (b) =>
        /^(next|continue|save and continue)$/i.test(b.textContent.trim()) &&
        isVisible(b) &&
        !b.disabled
    );
  }

  function isReviewOrSubmitStep() {
    return !!(
      document.querySelector('[data-automation-id="pageFooterSubmitButton"]') ||
      document.querySelector('button[data-automation-id*="submit" i]') ||
      Array.from(document.querySelectorAll("button")).find(
        (b) => /^submit$/i.test(b.textContent.trim()) && isVisible(b)
      )
    );
  }

  async function showReviewGate() {
    const overlay = document.createElement("div");
    overlay.id = "wf-autofill-review";

    const itemsHtml = manualReviewItems.length
      ? `<div class="wf-manual-list">
           <p class="wf-note">These fields need your input — the extension left them alone
           rather than risk clicking into Workday's own widgets:</p>
           <ul>${manualReviewItems
             .map(
               (item) =>
                 `<li><strong>${escapeHtml(item.label)}</strong>: suggested "${escapeHtml(
                   item.suggestion
                 )}"</li>`
             )
             .join("")}</ul>
         </div>`
      : "";

    overlay.innerHTML = `
      <div class="wf-panel">
        <h2>Review before submitting</h2>
        <p>The extension has filled the application through every step it recognized.
        Please scroll through the Workday form yourself to verify everything is correct —
        especially any custom questions — before you submit.</p>
        ${itemsHtml}
        <p class="wf-note">This extension will never click Submit for you.</p>
        <button id="wf-dismiss">Got it, let me review</button>
      </div>`;
    document.body.appendChild(overlay);
    document.getElementById("wf-dismiss").addEventListener("click", () => overlay.remove());
    toast("Reached the review/submit step. Autofill paused for your confirmation.", "ok");
  }

  function escapeHtml(str) {
    const div = document.createElement("div");
    div.textContent = str;
    return div.innerHTML;
  }

  // ============================================================
  // Repeatable sections — Work Experience / Education
  // ============================================================
  async function handleRepeatableSections() {
    const sections = [
      {
        key: "workExperience",
        title: "Work Experience",
        names: [/^work\s*experience$/i, /^experience$/i],
        records: Array.isArray(resumeProfile?.workExperience) ? resumeProfile.workExperience : [],
      },
      {
        key: "education",
        title: "Education",
        names: [/^education$/i],
        records: Array.isArray(resumeProfile?.education) ? resumeProfile.education : [],
      },
    ];

    for (const section of sections) {
      if (!section.records.length) continue;

      // Work Experience/Education only exist on the My Experience step.
      // Never search for their Add button on My Information or other steps.
      const sectionHeading = findSectionHeadingElement(section);
      if (!sectionHeading) {
        console.debug(`[Workday Autofill] ${section.title} is not on this step; skipping.`);
        continue;
      }

      // Workday initially renders only the section heading + Add button.
      // Therefore Add must be handled BEFORE the normal field scanner.
      let existing = countRepeatableEntries(section);
      let target = section.records.length;

      console.debug("[Workday Autofill] repeatable section", section.title, {
        existing,
        target,
        addButtons: findAddButtonsForSection(section.names).length,
      });

      while (existing < target) {
        console.debug("[Workday Autofill] locating Add", section.title, existing + 1);
        const clicked = await clickRepeatableAddButton(section, existing + 1);

        if (!clicked) {
          toast(
            `${section.title}: Add button was not available yet. Autofill paused.`,
            "err"
          );
          manualReviewItems.push({
            label: section.title,
            suggestion: `Click Add to create entry ${existing + 1}, then restart autofill.`
          });
          return { blocked: true };
        }

        // Do not immediately proceed to Save and Continue. Wait until the
        // actual entry form has appeared.
        const opened = await waitForRepeatableEntry(section, existing, 9000);
        if (!opened) {
          toast(
            `${section.title}: Add was clicked, but the entry form did not appear. Autofill paused.`,
            "err"
          );
          manualReviewItems.push({
            label: section.title,
            suggestion: `Click Add manually for entry ${existing + 1}.`
          });
          return { blocked: true };
        }

        // The Add click can replace the section subtree, which means a
        // fresh DOM-based recount may temporarily resolve to the new
        // "Work Experience 1" / "Education 1" heading instead of the
        // original section heading. Treat a successfully opened form as one
        // newly-created entry and only use the DOM count as a consistency
        // check. This prevents the extension from immediately looking for
        // another Add button after the first Add has already opened the form.
        const countedAfterAdd = countRepeatableEntries(section);
        existing = Math.max(existing + 1, countedAfterAdd);
        await waitForStableDom(500, 7000);
      }

      // Now that every requested entry exists, fill each entry independently.
      // This is important because generic field mapping would otherwise map
      // every Company/School field to resumeProfile[0].
      const entries = getRepeatableEntryContainers(section);
      console.debug("[Workday Autofill] entry containers", section.title, entries.length);

      for (let i = 0; i < Math.min(entries.length, section.records.length); i++) {
        const entryFields = FieldScanner.scan().filter(field =>
          isFieldInsideContainer(field.element, entries[i])
        );

        if (!entryFields.length) {
          toast(
            `${section.title} ${i + 1} opened, but its fields could not be identified. Autofill paused.`,
            "err"
          );
          manualReviewItems.push({
            label: `${section.title} ${i + 1}`,
            suggestion: "Complete this entry manually."
          });
          return { blocked: true };
        }

        await Mapper.fillRecord(entryFields, section.records[i]);
        await sleep(500);

        // Do NOT stop the whole My Experience step here. Workday can report
        // validation errors for a repeatable entry while other My Experience
        // sections (Skills, Websites, Social Network URLs, etc.) are still
        // waiting to be populated. Those fields must be given a chance to
        // fill before we make the final validation decision in runAutofillLoop.
        const errors = getValidationErrors();
        if (errors.length) {
          console.warn(`[Workday Autofill] ${section.title} ${i + 1} has
validation issues; continuing with the remaining My Experience sections first.`, errors);
          console.table(errors.map(message => ({ WorkdayValidationError: message })));
        }
      }
    }

    return { blocked: false };
  }

  function sectionTitleMatches(text, names) {
    const cleaned = cleanLabel(text).replace(/\s+/g, " ").trim();
    return names.some(re => re.test(cleaned.replace(/\s+\d+\s*$/, "")));
  }

  function getAllVisibleAddButtons() {
    // Workday commonly uses this stable automation id for the Add button in
    // repeatable/panel-set sections. Do not rely only on visible button text:
    // some tenants render the label through nested spans or accessibility
    // attributes after the panel is mounted.
    const selector = [
      '[data-automation-id="panelSetAddButton"]',
      'button',
      '[role="button"]',
      'a[role="button"]'
    ].join(',');

    const seen = new Set();
    return Array.from(document.querySelectorAll(selector)).filter(btn => {
      if (seen.has(btn)) return false;
      seen.add(btn);
      if (!isVisible(btn) || btn.disabled || btn.getAttribute('aria-disabled') === 'true') return false;

      const automationId = (btn.getAttribute('data-automation-id') || '').toLowerCase();
      const text = cleanLabel(
        btn.getAttribute('aria-label') ||
        btn.getAttribute('data-automation-label') ||
        btn.textContent || ''
      );

      return automationId === 'panelsetaddbutton' ||
        /^(add|add\s+another|add\s+one|add\s+more)$/i.test(text);
    });
  }

  function findAddButtonsForSection(names) {
    const allButtons = getAllVisibleAddButtons();
    if (!allButtons.length) return [];

    const heading = findSectionHeadingElement({ names });
    if (!heading) return [];

    const headingRect = heading.getBoundingClientRect();
    const headingTop = headingRect.top;
    const headingLeft = headingRect.left;
    const headingRight = headingRect.right;

    // This NVIDIA Workday page renders the green Add button directly BELOW
    // the section title (not on the same row). Use the actual visual layout:
    // same horizontal column + nearest Add below the heading.
    const visibleCandidates = allButtons
      .map(btn => ({ btn, rect: btn.getBoundingClientRect() }))
      .filter(({ rect }) => {
        if (rect.top < headingTop - 10) return false;
        if (rect.top - headingTop > 420) return false;

        // Prefer buttons in the same content column as the heading. Allow a
        // generous overlap because Workday's responsive containers vary.
        const horizontalOverlap = rect.right >= headingLeft - 120 &&
          rect.left <= headingRight + 120;
        return horizontalOverlap;
      });

    const panelCandidates = visibleCandidates.filter(({ btn }) =>
      (btn.getAttribute('data-automation-id') || '').toLowerCase() === 'panelsetaddbutton'
    );

    const ranked = (panelCandidates.length ? panelCandidates : visibleCandidates)
      .sort((a, b) => {
        const aDistance = Math.max(0, a.rect.top - headingRect.bottom);
        const bDistance = Math.max(0, b.rect.top - headingRect.bottom);

        // Exact vertical alignment with the heading column is useful, but
        // distance below the heading is the strongest signal on this page.
        const aCenter = (a.rect.left + a.rect.right) / 2;
        const bCenter = (b.rect.left + b.rect.right) / 2;
        const headingCenter = (headingLeft + headingRight) / 2;
        const aHorizontal = Math.abs(aCenter - headingCenter);
        const bHorizontal = Math.abs(bCenter - headingCenter);

        return (aDistance - bDistance) || (aHorizontal - bHorizontal);
      });

    if (ranked.length) {
      console.debug('[Workday Autofill] Add candidates for section', {
        section: names.map(String).join('|'),
        heading: cleanLabel(heading.textContent || ''),
        candidates: ranked.slice(0, 5).map(({ btn, rect }) => ({
          text: cleanLabel(btn.textContent || btn.getAttribute('aria-label') || ''),
          automationId: btn.getAttribute('data-automation-id'),
          top: Math.round(rect.top),
          left: Math.round(rect.left),
          distanceFromHeadingBottom: Math.round(rect.top - headingRect.bottom),
          html: btn.outerHTML.slice(0, 300)
        }))
      });
      return [ranked[0].btn];
    }

    return [];
  }

  function findSectionHeadingElement(section) {
    const selector = 'h1,h2,h3,h4,[role="heading"],div,span,p';
    const candidates = Array.from(document.querySelectorAll(selector)).filter(el => {
      if (!isVisible(el)) return false;
      const text = cleanLabel(el.textContent || '');
      // Resolve the parent SECTION heading only. After clicking Add, Workday
      // creates "Work Experience 1" / "Education 1"; those are entry
      // headings and must not become the section anchor.
      const exact = section.names.some(re => re.test(text));
      return text.length <= 80 && exact;
    });

    if (!candidates.length) return null;

    // Prefer semantic Workday/HTML headings first.
    const semantic = candidates.filter(el =>
      /^H[1-4]$/.test(el.tagName) || el.getAttribute('role') === 'heading'
    );
    if (semantic.length) {
      return semantic.sort((a, b) =>
        a.getBoundingClientRect().top - b.getBoundingClientRect().top
      )[0];
    }

    // For Workday's div/span headings, prefer the smallest exact-match
    // element. Numbered entry headings are intentionally excluded above.
    const pool = candidates;

    return pool.sort((a, b) => {
      const ar = a.getBoundingClientRect();
      const br = b.getBoundingClientRect();
      const aArea = ar.width * ar.height;
      const bArea = br.width * br.height;
      return (aArea - bArea) || (ar.top - br.top);
    })[0];
  }

  async function waitForAddButton(section, timeoutMs = 8000) {
    const started = Date.now();
    while (Date.now() - started < timeoutMs) {
      const buttons = findAddButtonsForSection(section.names);
      if (buttons.length) return buttons[0];
      await sleep(250);
    }
    return null;
  }

  function getWorkdayPanelSetAddButtons() {
    return Array.from(document.querySelectorAll('[data-automation-id="panelSetAddButton"]'))
      .filter(el => isVisible(el) && !el.disabled && el.getAttribute('aria-disabled') !== 'true');
  }

  async function clickRepeatableAddButton(section, entryNumber) {
    const started = Date.now();
    let btn = null;

    while (Date.now() - started < 10000 && !btn) {
      // Work Experience's first Add is reliably the first Workday panel-set
      // Add on this page. For Education, however, the Work Experience panel
      // is already expanded by the time we get here, so panel-set indexes can
      // shift. Resolve Education semantically from its heading instead.
      if (section.key === "workExperience" && entryNumber === 1) {
        const panelButtons = getWorkdayPanelSetAddButtons();
        if (panelButtons[0]) btn = panelButtons[0];
      }

      if (!btn) btn = findSectionScopedAddButton(section, entryNumber);
      if (!btn) await sleep(250);
    }

    if (!btn) {
      console.debug('[Workday Autofill] No section Add control found', {
        section: section.title,
        entryNumber,
        panelSetButtons: getWorkdayPanelSetAddButtons().map((el, index) => ({
          index,
          text: cleanLabel(el.textContent || el.getAttribute('aria-label') || ''),
          html: el.outerHTML.slice(0, 700)
        }))
      });
      return false;
    }

    console.debug('[Workday Autofill] Add target', {
      section: section.title,
      entryNumber,
      text: cleanLabel(btn.textContent || btn.getAttribute('aria-label') || ''),
      tag: btn.tagName,
      automationId: btn.getAttribute('data-automation-id'),
      html: btn.outerHTML.slice(0, 1200)
    });

    btn.scrollIntoView({ block: 'center', inline: 'nearest', behavior: 'instant' });
    await sleep(300);

    const target = btn.closest('button,[role="button"],a') || btn;
    try {
      target.click();
    } catch (e) {
      console.debug('[Workday Autofill] Add click failed', e);
      return false;
    }

    // Give Workday enough time to replace the panel subtree.
    await sleep(1000);
    return true;
  }

  function findSectionScopedAddButton(section, entryNumber) {
    const heading = findSectionHeadingElement(section);
    if (!heading) return null;

    const hr = heading.getBoundingClientRect();
    const headingBottom = hr.bottom;

    // IMPORTANT: after Work Experience is expanded, its button changes from
    // "Add" to "Add Another". Education still has a plain "Add" button.
    // Therefore for the first Education entry, prefer an EXACT "Add" label
    // rather than relying on panelSetAddButton indexes or the Work Experience
    // button order. This matches the actual NVIDIA page layout shown by the
    // user: Education -> Add -> (new Education entry).
    const normalizeButtonText = (btn) => cleanLabel(
      btn.getAttribute('aria-label') ||
      btn.getAttribute('data-automation-label') ||
      btn.textContent || ''
    ).replace(/\s+/g, ' ').trim();

    const all = getAllVisibleAddButtons()
      .map(btn => ({ btn, rect: btn.getBoundingClientRect(), text: normalizeButtonText(btn) }))
      .filter(({ rect }) => rect.top >= headingBottom - 6);

    if (!all.length) return null;

    // Find the next real My Experience section boundary. Do not use every
    // nested div/span because Workday contains many duplicated label nodes.
    const boundaryNames = [
      /^work\s*experience$/i,
      /^experience$/i,
      /^education$/i,
      /^skills$/i,
      /^resume\s*\/?\s*cv$/i,
      /^websites$/i,
      /^social\s*network\s*urls?$/i,
    ];

    const currentTop = hr.top;
    const boundaryTops = [];
    for (const el of Array.from(document.querySelectorAll('h1,h2,h3,h4,[role="heading"],div,span,p'))) {
      if (!isVisible(el) || el === heading) continue;
      const text = cleanLabel(el.textContent || '').replace(/\s+/g, ' ').trim();
      if (text.length > 80) continue;
      if (!boundaryNames.some(re => re.test(text))) continue;
      const r = el.getBoundingClientRect();
      if (r.top > currentTop + 8) boundaryTops.push(r.top);
    }
    const nextBoundaryTop = boundaryTops.length ? Math.min(...boundaryTops) : Infinity;

    const withinSection = all.filter(({ rect }) => rect.top < nextBoundaryTop - 5);
    if (!withinSection.length) return null;

    // For Education's first entry, EXACT "Add" is the strongest signal.
    // This deliberately excludes Work Experience's "Add Another" button.
    const exactAdd = withinSection.filter(({ text }) => /^add$/i.test(text));
    if (exactAdd.length) {
      exactAdd.sort((a, b) => {
        const ad = Math.max(0, a.rect.top - headingBottom);
        const bd = Math.max(0, b.rect.top - headingBottom);
        return ad - bd;
      });

      console.debug('[Workday Autofill] exact Add selected', {
        section: section.title,
        entryNumber,
        heading: cleanLabel(heading.textContent || ''),
        nextBoundaryTop,
        candidates: exactAdd.slice(0, 5).map(({ btn, rect, text }) => ({
          text,
          automationId: btn.getAttribute('data-automation-id'),
          top: Math.round(rect.top),
          left: Math.round(rect.left),
          html: btn.outerHTML.slice(0, 500)
        }))
      });
      return exactAdd[0].btn;
    }

    // Fallback for tenants that render the button label through an
    // accessibility attribute or change it to Add One/Add More.
    const panel = withinSection.filter(({ btn }) =>
      (btn.getAttribute('data-automation-id') || '').toLowerCase() === 'panelsetaddbutton'
    );
    const candidates = panel.length ? panel : withinSection;

    candidates.sort((a, b) => {
      const ad = Math.max(0, a.rect.top - headingBottom);
      const bd = Math.max(0, b.rect.top - headingBottom);
      const aAnother = /^add\s+another$/i.test(a.text) ? 1 : 0;
      const bAnother = /^add\s+another$/i.test(b.text) ? 1 : 0;
      return (aAnother - bAnother) || (ad - bd);
    });

    if (!candidates.length) return null;

    console.debug('[Workday Autofill] fallback Add selected', {
      section: section.title,
      entryNumber,
      heading: cleanLabel(heading.textContent || ''),
      candidate: {
        text: candidates[0].text,
        automationId: candidates[0].btn.getAttribute('data-automation-id'),
        html: candidates[0].btn.outerHTML.slice(0, 700)
      }
    });

    return candidates[0].btn;
  }

  function findNextMajorHeadingTop(currentHeading) {
    const currentTop = currentHeading.getBoundingClientRect().top;
    const candidates = Array.from(document.querySelectorAll('h1,h2,h3,h4,[role="heading"]'))
      .filter(el => isVisible(el) && el !== currentHeading)
      .map(el => ({ el, rect: el.getBoundingClientRect() }))
      .filter(({ rect }) => rect.top > currentTop + 10);

    if (!candidates.length) return Number.POSITIVE_INFINITY;
    return Math.min(...candidates.map(({ rect }) => rect.top));
  }

  function getSectionRoot(section) {
    const heading = findSectionHeadingElement(section);
    if (!heading) return null;

    let node = heading.parentElement;
    let best = node;
    for (let depth = 0; node && depth < 8; depth++, node = node.parentElement) {
      const controls = Array.from(node.querySelectorAll(
        'input:not([type="hidden"]),textarea,select,[role="combobox"],[role="listbox"]'
      )).filter(isVisible);
      const adds = getAllVisibleAddButtons().filter(btn => node.contains(btn));
      if (controls.length || adds.length) best = node;
      const rect = node.getBoundingClientRect();
      if (rect.height > window.innerHeight * 0.95 && depth > 2) break;
    }
    return best;
  }

  function getSectionBounds(section) {
    const heading = findSectionHeadingElement(section);
    if (!heading) return null;
    const hr = heading.getBoundingClientRect();
    const major = Array.from(document.querySelectorAll('h1,h2,h3,h4,[role="heading"]'))
      .filter(el => isVisible(el) && el !== heading)
      .map(el => ({ el, rect: el.getBoundingClientRect(), text: cleanLabel(el.textContent || '').replace(/\s+/g, ' ').trim() }))
      .filter(({ rect }) => rect.top > hr.top + 8 && rect.height > 0);
    const next = major.length ? Math.min(...major.map(x => x.rect.top)) : Number.POSITIVE_INFINITY;
    return { heading, top: hr.bottom, nextTop: next };
  }

  function getSectionScopedElements(section) {
    const bounds = getSectionBounds(section);
    if (!bounds) return [];
    return Array.from(document.querySelectorAll('*')).filter(el => {
      if (!isVisible(el)) return false;
      const r = el.getBoundingClientRect();
      return r.top >= bounds.top - 8 && r.top < bounds.nextTop - 5;
    });
  }

  function countRepeatableEntries(section) {
    // IMPORTANT: Do not use a broad ancestor/container to count entries.
    // After Work Experience is opened, its controls can live inside an
    // ancestor that also contains Education. That used to make Education
    // look like it already had an entry, so its Add button was skipped.
    const bounds = getSectionBounds(section);
    if (!bounds) return 0;

    const numbered = getSectionScopedElements(section).filter(el => {
      if (el.children.length > 4) return false;
      const text = cleanLabel(el.textContent || '').replace(/\s+/g, ' ').trim();
      return section.key === 'workExperience'
        ? /^work\s*experience\s*\d+$/i.test(text)
        : /^education\s*\d+$/i.test(text);
    });

    return new Set(numbered.map(el => cleanLabel(el.textContent || '').replace(/\s+/g, ' ').trim())).size;
  }

  function getRepeatableEntryContainers(section) {
    const bounds = getSectionBounds(section);
    if (!bounds) return [];

    const numbered = getSectionScopedElements(section).filter(el => {
      if (el.children.length > 6) return false;
      const text = cleanLabel(el.textContent || '').replace(/\s+/g, ' ').trim();
      return section.key === 'workExperience'
        ? /^work\s*experience\s*\d+$/i.test(text)
        : /^education\s*\d+$/i.test(text);
    });

    const containers = [];
    for (const entryHeading of numbered) {
      let node = entryHeading.parentElement;
      for (let depth = 0; node && depth < 8; depth++, node = node.parentElement) {
        const nr = node.getBoundingClientRect();
        // Never accept a container that extends into another major section.
        if (nr.top < bounds.top - 20 || nr.top >= bounds.nextTop - 5) continue;
        const controls = Array.from(node.querySelectorAll(
          'input:not([type="hidden"]),textarea,select,[role="combobox"],[role="listbox"]'
        )).filter(isVisible).filter(c => {
          const cr = c.getBoundingClientRect();
          return cr.top >= bounds.top - 5 && cr.top < bounds.nextTop - 5;
        });
        if (controls.length >= 2) {
          containers.push(node);
          break;
        }
      }
    }

    if (containers.length) return [...new Set(containers)];

    return [];
  }

  async function waitForRepeatableEntry(section, previousCount, timeoutMs) {
    const started = Date.now();
    while (Date.now() - started < timeoutMs) {
      await sleep(250);
      if (countRepeatableEntries(section) > previousCount) return true;

      const bounds = getSectionBounds(section);
      if (bounds) {
        const controls = getSectionScopedElements(section).filter(el => {
          const tag = el.tagName;
          return tag === 'INPUT' || tag === 'TEXTAREA' || tag === 'SELECT' ||
            el.getAttribute('role') === 'combobox' || el.getAttribute('role') === 'listbox';
        });
        // A newly rendered Education form has visible controls between the
        // Education heading and the next major section. Do not count the
        // already-open Work Experience controls above it.
        if (controls.some(isVisible)) return true;
      }
    }
    return false;
  }

  function isFieldInsideContainer(element, container) {
    return !!(element && container && (container === element || container.contains(element)));
  }

  function isRepeatableField(element) {
    if (!element) return false;

    // IMPORTANT: Do not use getSectionRoot() here. Workday often puts the
    // entire My Experience page inside one large React container, so the
    // ancestor of Education can also contain Skills, Resume/CV, Websites,
    // etc. The old ancestor test therefore incorrectly hid everything after
    // Education from the generic mapper.
    //
    // Instead, scope only by the visual/semantic section boundaries: from
    // the section heading down to the next major heading. On the NVIDIA page
    // this gives exactly:
    //   Work Experience -> Education
    //   Education       -> Skills
    // so Skills remains available to Mapper.fillAll().
    const sections = [
      { names: [/^work\s*experience$/i, /^experience$/i] },
      { names: [/^education$/i] },
    ];

    const er = element.getBoundingClientRect();
    return sections.some(section => {
      const bounds = getSectionBounds(section);
      if (!bounds) return false;
      return er.top >= bounds.top - 8 && er.top < bounds.nextTop - 5;
    });
  }

  // ============================================================
  // FieldScanner — discovers Workday fields on the current step
  // ============================================================
  const FieldScanner = {
    scan() {
      const fields = [];
      const seen = new Set();

      // Workday commonly puts a stable automation id on the actual input,
      // while the surrounding formField-* wrapper may vary by tenant.
      const controls = Array.from(document.querySelectorAll(
        'input:not([type="hidden"]), textarea, select, [role="combobox"], [role="listbox"]'
      ));

      for (const control of controls) {
        if (!isVisible(control) || isDisabled(control)) continue;

        let type = classifyControl(control);
        // Workday date fields are often plain text inputs with a YYYY or MM/YYYY
        // mask rather than <input type="date">. Detect those explicitly so
        // they use the date-aware filler below.
        const preliminaryLabel = extractLabelForControl(control,
          control.closest('[data-automation-id^="formField-"]') ||
          control.closest('[data-automation-id="formField"]') ||
          control.closest("fieldset") ||
          control.parentElement
        );
        if (type === "text" && isWorkdayDateControl(control, preliminaryLabel)) {
          type = "date";
        }
        // File inputs cannot be filled by a browser extension for security reasons.
        if ((control.getAttribute("type") || "").toLowerCase() === "file") continue;

        const wrapper =
          control.closest('[data-automation-id^="formField-"]') ||
          control.closest('[data-automation-id="formField"]') ||
          control.closest("fieldset") ||
          control.closest('[role="group"]') ||
          control.parentElement;

        const label = extractLabelForControl(control, wrapper);
        if (!label) continue;

        // Radio/checkbox groups should be represented once, not once per input.
        const groupKey =
          type === "radio" || type === "checkbox"
            ? (wrapper?.getAttribute("data-automation-id") || label)
            : (control.getAttribute("data-automation-id") ||
               control.id ||
               `${label}|${type}`);

        if (seen.has(groupKey)) continue;
        seen.add(groupKey);

        const groupControl =
          type === "radio" || type === "checkbox"
            ? (wrapper?.querySelector(`input[type="${type}"]`) || control)
            : control;

        fields.push({
          id: `wf-field-${fields.length}`,
          label,
          type,
          element: groupControl,
          wrapper: wrapper || control.parentElement,
          automationId: control.getAttribute("data-automation-id") || "",
          options: extractOptions(wrapper || control.parentElement, groupControl),
        });
      }

      console.debug("[Workday Autofill] scanned fields:", fields.map(f => ({
        id: f.id, label: f.label, type: f.type, automationId: f.automationId, options: f.options
      })));

      return fields;
    },
  };

  function extractLabelForControl(control, wrapper) {
    // 1. Explicit <label for="..."> is the most reliable association.
    if (control.id) {
      const explicit = document.querySelector(`label[for="${CSS.escape(control.id)}"]`);
      if (explicit?.textContent?.trim()) {
        return cleanLabel(explicit.textContent);
      }
    }

    // 2. Workday frequently exposes an aria-label / aria-labelledby.
    const ariaLabel = control.getAttribute("aria-label");
    if (ariaLabel?.trim()) return cleanLabel(ariaLabel);

    const labelledBy = control.getAttribute("aria-labelledby");
    if (labelledBy) {
      const text = labelledBy.split(/\s+/)
        .map(id => document.getElementById(id)?.textContent || "")
        .join(" ")
        .trim();
      if (text) return cleanLabel(text);
    }

    // 3. Look in the nearest Workday form wrapper.
    if (wrapper) {
      const labelEl = wrapper.querySelector("label");
      if (labelEl?.textContent?.trim()) return cleanLabel(labelEl.textContent);

      const rich = wrapper.querySelector('[data-automation-id="richText"]');
      if (rich?.textContent?.trim()) return cleanLabel(rich.textContent);

      const wrapperAria = wrapper.getAttribute("aria-label");
      if (wrapperAria?.trim()) return cleanLabel(wrapperAria);
    }

    // 4. Last-resort: preceding text in the same small container.
    let parent = control.parentElement;
    for (let i = 0; i < 3 && parent; i++, parent = parent.parentElement) {
      const text = Array.from(parent.childNodes)
        .filter(n => n.nodeType === Node.TEXT_NODE)
        .map(n => n.textContent.trim())
        .filter(Boolean)
        .join(" ");
      if (text) return cleanLabel(text);
    }

    return null;
  }

  function cleanLabel(text) {
    return String(text)
      .replace(/\s+/g, " ")
      .replace(/\s*\*+\s*$/, "")
      .trim();
  }

  function isDisabled(el) {
    return !!(
      el.disabled ||
      el.getAttribute("aria-disabled") === "true" ||
      el.closest("[aria-disabled='true']")
    );
  }

  function findControl(wrapper) {
    return wrapper?.querySelector(
      'input:not([type="hidden"]), select, textarea, [role="listbox"], [role="combobox"]'
    ) || null;
  }

  function classifyControl(el) {
    const tag = el.tagName.toLowerCase();
    const type = (el.getAttribute("type") || "").toLowerCase();
    const role = el.getAttribute("role");

    if (tag === "select") return "select";
    if (tag === "textarea") return "textarea";
    if (type === "radio") return "radio";
    if (type === "checkbox") return "checkbox";
    if (type === "date" || el.closest('[data-automation-id*="datePicker" i]') ||
        /^(date|month|year|mm\/?yyyy|yyyy)$/.test((el.getAttribute("placeholder") || "").trim().toLowerCase())) return "date";
    if (role === "listbox" || role === "combobox" ||
        el.dataset.automationId === "selectInputIcon" ||
        el.getAttribute("aria-haspopup") === "listbox") return "workday-select";
    return "text";
  }

  function isWorkdayDateControl(el, label) {
    if (!el) return false;
    const placeholder = (el.getAttribute("placeholder") || "").trim().toLowerCase();
    const automation = (el.getAttribute("data-automation-id") || "").toLowerCase();
    const aria = (el.getAttribute("aria-label") || "").toLowerCase();
    const text = `${label || ""} ${placeholder} ${automation} ${aria}`;
    return /(^|\s)(from|to|start|end)(\s|$)/i.test(label || "") ||
      /mm\/?yyyy|yyyy|date|datepicker|dateinput|datefield/.test(text);
  }

  function extractOptions(wrapper, control) {
    if (!wrapper && !control) return [];

    if (control?.tagName?.toLowerCase() === "select") {
      return Array.from(control.options)
        .map(o => o.textContent.trim())
        .filter(Boolean);
    }

    const radios = wrapper?.querySelectorAll('input[type="radio"], input[type="checkbox"]') || [];
    if (radios.length) {
      return Array.from(radios).map(r => {
        const lbl = r.id ? document.querySelector(`label[for="${CSS.escape(r.id)}"]`) : null;
        return (lbl?.textContent || r.value || "").trim();
      }).filter(Boolean);
    }

    // Open listboxes are often rendered elsewhere in the document.
    const listbox = wrapper?.querySelector('[role="listbox"]');
    if (listbox) {
      return Array.from(listbox.querySelectorAll('[role="option"]'))
        .map(o => (o.textContent || "").trim())
        .filter(Boolean);
    }

    return [];
  }

  // ============================================================
  // Mapper — heuristics first, AI for anything left over
  // ============================================================
  const HEURISTICS = [
    [/first\s*name|given\s*name/i, (p) => p.firstName],
    [/last\s*name|family\s*name|surname/i, (p) => p.lastName],
    [/full\s*name/i, (p) => p.fullName],
    [/e-?mail/i, (p) => p.email],
    [/phone|mobile/i, (p) => p.phone],
    [/linkedin/i, (p) => p.linkedin],
    [/github/i, (p) => p.github],
    [/portfolio|website/i, (p) => p.portfolio],
    [/^city$|city\/town/i, (p) => p.location?.city],
    [/state|province/i, (p) => p.location?.state],
    [/country/i, (p) => p.location?.country],
    [/years?\s*of\s*experience/i, (p) => (p.yearsOfExperience != null ? String(p.yearsOfExperience) : null)],
    [/current\s*(job\s*)?title|most\s*recent\s*title/i, (p) => p.workExperience?.[0]?.title],
    [/current\s*(company|employer)/i, (p) => p.workExperience?.[0]?.company],
    [/^skills$|type\s*to\s*add\s*skills|technical\s*skills|core\s*skills|key\s*skills|competencies|technologies/i, (p) => Array.isArray(p.skills) ? p.skills.join(", ") : p.skills],
    [/school|university|institution/i, (p) => p.education?.[0]?.school],
    [/degree/i, (p) => p.education?.[0]?.degree],
    [/field\s*of\s*study|major/i, (p) => p.education?.[0]?.fieldOfStudy],
    [/summary|about\s*you/i, (p) => p.summary],
  ];

  const Mapper = {
    async fillAll(fields) {
      const unresolved = [];
      for (const field of fields) {
        const value = matchHeuristic(field.label);
        if (value !== null && value !== undefined && String(value).trim() !== "") {
          await Filler.fill(field, value);
          await sleep(120);
        } else {
          unresolved.push(field);
        }
      }
      if (unresolved.length) {
        await Mapper.resolveWithAI(unresolved);
      }
    },

    async fillRecord(fields, record) {
      const unresolved = [];

      for (const field of fields) {
        const value = matchRecordField(field.label, record, field);

        if (value !== null && value !== undefined && String(value).trim() !== "") {
          await Filler.fill(field, value);
          await sleep(120);
        } else {
          unresolved.push(field);
        }
      }

      // AI receives the individual record rather than the entire resume. This
      // prevents a second/third Work Experience entry from being populated
      // with the first employer.
      if (unresolved.length) {
        try {
          const response = await chrome.runtime.sendMessage({
            type: "MAP_FIELDS",
            payload: {
              fields: unresolved.map(f => ({
                fieldId: f.id,
                label: f.label,
                type: f.type,
                options: f.options,
              })),
              resumeProfile: record,
              apiKey: groqApiKey,
            },
          });

          if (response?.ok) {
            const answers = new Map(
              (response.data?.answers || []).map(a => [a.fieldId, a])
            );

            for (const field of unresolved) {
              const answer = answers.get(field.id);
              if (answer?.value && answer.value !== "DECLINE") {
                await Filler.fill(field, answer.value);
                await sleep(120);
              }
            }
          }
        } catch (err) {
          console.warn("[Workday Autofill] record AI mapping skipped:", err.message);
        }
      }
    },

    async resolveWithAI(fields) {
      const batch = fields.map((f) => ({
        fieldId: f.id,
        label: f.label,
        type: f.type,
        options: f.options,
      }));
      try {
        const response = await chrome.runtime.sendMessage({
          type: "MAP_FIELDS",
          payload: { fields: batch, resumeProfile, apiKey: groqApiKey },
        });
        if (!response || !response.ok) throw new Error(response?.error || "AI mapping failed");
        const answers = new Map(response.data.answers.map((a) => [a.fieldId, a]));
        for (const field of fields) {
          const answer = answers.get(field.id);
          if (answer && answer.value && answer.value !== "DECLINE") {
            await Filler.fill(field, answer.value);
            await sleep(120);
          }
        }
      } catch (err) {
        console.warn("[Workday Autofill] AI mapping skipped:", err.message);
      }
    },
  };

  function matchRecordField(label, record, field = {}) {
    if (!record) return null;
    const l = cleanLabel(label).toLowerCase();
    const type = field.type || "";

    // Work Experience
    if (/company|employer|organization/.test(l)) return record.company ?? null;
    if (/job\s*title|position|title/.test(l)) return record.title ?? null;
    if (/location|city|work\s*location/.test(l)) return record.location ?? null;

    // Workday often labels these simply "From" and "To", with the section
    // context telling us they are employment dates.
    if (/^(from|start|start\s*date)$/.test(l) || /start\s*date|employment\s*start/.test(l)) {
      return formatWorkdayDate(record.startDate);
    }
    if (/^(to|end|end\s*date)$/.test(l) || /end\s*date|employment\s*end/.test(l)) {
      return record.current ? null : formatWorkdayDate(record.endDate);
    }

    // "I currently work here" is a checkbox, so its label will not contain
    // "yes/no". Return the semantic boolean for checkbox/radio controls.
    if (/currently\s*work|currently\s*employed|current\s*position|present\s*job/.test(l)) {
      return record.current ? "Yes" : "No";
    }

    if (/description|responsibilit|duties|role\s*description|job\s*description|summary/.test(l)) {
      return record.description ?? null;
    }

    // Education
    if (/school|university|college|institution/.test(l)) return record.school ?? null;
    if (/degree|qualification/.test(l)) return record.degree ?? null;
    if (/field\s*of\s*study|major|specialization|discipline/.test(l)) {
      return record.fieldOfStudy ?? null;
    }
    if (/gpa|grade|overall\s*result|result/.test(l)) return record.gpa ?? record.grade ?? null;

    // Education date labels are also often just From / To. We distinguish
    // them by looking at the nearest section.
    if (/^(from|start|start\s*date)$/.test(l) || /start\s*date/.test(l)) {
      return formatWorkdayDate(record.startDate);
    }
    if (/^(to|end|end\s*date)$/.test(l) || /end\s*date/.test(l)) {
      return formatWorkdayDate(record.endDate);
    }

    return null;
  }

  function formatWorkdayDate(value) {
    if (!value) return null;
    const text = String(value).trim();

    // Preserve YYYY-MM-DD because native Workday date controls generally
    // accept it. Convert common MM/YYYY or MM-DD-YYYY variants when needed.
    if (/^\d{4}-\d{2}-\d{2}$/.test(text)) return text;

    let m = text.match(/^(\d{1,2})[\/-](\d{1,2})[\/-](\d{4})$/);
    if (m) return `${m[3]}-${String(m[1]).padStart(2,"0")}-${String(m[2]).padStart(2,"0")}`;

    m = text.match(/^(\d{1,2})[\/-](\d{4})$/);
    if (m) return `${m[2]}-${String(m[1]).padStart(2,"0")}-01`;

    m = text.match(/^(\d{4})$/);
    if (m) return `${m[1]}-01-01`;

    return text;
  }

  function matchHeuristic(label) {
    for (const [pattern, extractor] of HEURISTICS) {
      if (pattern.test(label)) {
        const value = extractor(resumeProfile);
        if (value) return String(value);
      }
    }
    return null;
  }

  // ============================================================
  // Filler — updates controls and dispatches the events Workday listens for
  // ============================================================
  const Filler = {
    async fill(field, value) {
      const el = field.element;
      if (!el) return;

      try {
        const normalized = String(value).trim();
        if (!normalized) return;

        if (field.type === "date") {
          await fillWorkdayDateField(el, normalized);
        } else if (field.type === "text" || field.type === "textarea") {
          await typeIntoField(el, normalized);
        } else if (field.type === "select") {
          selectOption(el, normalized);
        } else if (field.type === "radio" || field.type === "checkbox") {
          selectChoice(field.wrapper, normalized);
        } else if (field.type === "workday-select") {
          await fillWorkdaySelect(field, normalized);
        }

        console.debug("[Workday Autofill] filled:", field.label, normalized);
      } catch (err) {
        console.warn("[Workday Autofill] could not fill field:", field.label, err);
        flagForManualEntry(field, String(value));
      }
    },
  };

  function flagForManualEntry(field, suggestedValue) {
    const already = manualReviewItems.some(x => x.label === field.label);
    if (!already) manualReviewItems.push({ label: field.label, suggestion: suggestedValue });
  }

  function formatDateForWorkdayInput(el, value) {
    const text = String(value || "").trim();
    if (!text) return "";

    let year = "", month = "", day = "";
    let m = text.match(/^(\d{4})-(\d{1,2})-(\d{1,2})$/);
    if (m) {
      year = m[1]; month = String(m[2]).padStart(2, "0"); day = String(m[3]).padStart(2, "0");
    } else if ((m = text.match(/^(\d{1,2})[\/-](\d{1,2})[\/-](\d{4})$/))) {
      month = String(m[1]).padStart(2, "0"); day = String(m[2]).padStart(2, "0"); year = m[3];
    } else if ((m = text.match(/^(\d{1,2})[\/-](\d{4})$/))) {
      month = String(m[1]).padStart(2, "0"); year = m[2];
    } else if ((m = text.match(/^(\d{4})$/))) {
      year = m[1];
    } else {
      return text;
    }

    const placeholder = (el.getAttribute("placeholder") || "").trim().toUpperCase();
    if (/^YYYY$/.test(placeholder) || /YEAR/.test(placeholder)) return year;
    if (/MM\/?YYYY/.test(placeholder)) return month && year ? `${month}/${year}` : year;
    if (/MM[\/-]DD[\/-]YYYY/.test(placeholder)) return `${month}/${day || "01"}/${year}`;
    if (/YYYY[\/-]MM[\/-]DD/.test(placeholder)) return `${year}-${month}-${day || "01"}`;

    // If Workday exposes a native date input, use the ISO value.
    if ((el.getAttribute("type") || "").toLowerCase() === "date") {
      return `${year}-${month || "01"}-${day || "01"}`;
    }
    return month && year ? `${month}/${year}` : year;
  }

  async function fillWorkdayDateField(el, value) {
    const displayValue = formatDateForWorkdayInput(el, value);
    if (!displayValue) return;

    const inputType = (el.getAttribute("type") || "text").toLowerCase();
    // Native <input type=date> expects the ISO representation. Workday's
    // masked YYYY/MM/YYYY controls are text inputs and must receive the
    // displayed value through the React bridge.
    if (inputType === "date") {
      await typeIntoField(el, displayValue);
      return;
    }

    await typeIntoField(el, displayValue);
  }

  async function fillWorkdaySelect(field, value) {
    const el = field.element;
    const wanted = String(value || "").trim();
    if (!el || !wanted) return;

    el.scrollIntoView({ block: "center", behavior: "instant" });

    const normalize = (text) => cleanLabel(String(text || ""))
      .toLowerCase()
      .replace(/[’']/g, "'")
      .replace(/&/g, "and")
      .replace(/[^a-z0-9]+/g, " ")
      .replace(/\s+/g, " ")
      .trim();

    const synonym = (text) => normalize(text)
      .replace(/\bb\.?\s*tech\.?\b/g, "bachelor of technology")
      .replace(/\bbtech\b/g, "bachelor of technology")
      .replace(/\bm\.?\s*tech\.?\b/g, "master of technology")
      .replace(/\bmtech\b/g, "master of technology")
      .replace(/\bb\.?\s*e\.?\b/g, "bachelor of engineering")
      .replace(/\bbe\b/g, "bachelor of engineering")
      .replace(/\bm\.?\s*e\.?\b/g, "master of engineering")
      .replace(/\bme\b/g, "master of engineering")
      .replace(/\bmba\b/g, "master of business administration")
      .replace(/\bbca\b/g, "bachelor of computer applications")
      .replace(/\bmca\b/g, "master of computer applications");

    const wantedNorm = synonym(wanted);

    const optionNodes = () => Array.from(document.querySelectorAll(
      '[role="option"], li[role="option"], [data-automation-id*="selectOption" i],\n' +
      '[data-automation-id*="promptOption" i], [data-automation-id*="dropdownOption" i]'
    )).filter(isVisible);

    const optionText = (node) => cleanLabel(
      node?.textContent || node?.getAttribute("aria-label") || node?.getAttribute("data-value") || ""
    );

    const chooseBestVisibleOption = () => {
      const options = optionNodes()
        .map(node => ({ node, text: optionText(node), norm: synonym(optionText(node)) }))
        .filter(x => x.text);
      if (!options.length) return null;

      // Exact match after normalizing punctuation/spacing and common degree
      // abbreviations (B.Tech <-> Bachelor of Technology, etc.).
      let hit = options.find(x => x.norm === wantedNorm);
      if (hit) return hit.node;

      // Prefer a contained match for cases such as "Bachelor of Technology
      // (B.Tech)" where the resume only contains the shorter form.
      hit = options.find(x => x.norm.includes(wantedNorm) || wantedNorm.includes(x.norm));
      if (hit) return hit.node;

      // Small token-overlap fallback, but only when the overlap is strong.
      const tokens = wantedNorm.split(' ').filter(Boolean);
      let best = null;
      let bestScore = 0;
      for (const candidate of options) {
        const ct = new Set(candidate.norm.split(' '));
        const overlap = tokens.filter(t => ct.has(t)).length;
        const score = tokens.length ? overlap / tokens.length : 0;
        if (score > bestScore) {
          bestScore = score;
          best = candidate.node;
        }
      }
      return bestScore >= 0.75 ? best : null;
    };

    // Workday can render the visual combobox as a div while keeping a real
    // input/button inside its form-field wrapper. Click all the appropriate
    // layers so the popup actually opens before we search for options.
    const wrapper = el.closest('[data-automation-id^="formField-"]') ||
      el.closest('[data-automation-id="formField"]') || el.parentElement;
    const trigger = el.matches('input,button,[role="combobox"],[role="listbox"]')
      ? el
      : (wrapper?.querySelector('input,button,[role="combobox"],[role="listbox"]') || el);

    try {
      trigger.focus();
      trigger.dispatchEvent(new MouseEvent('mousedown', { bubbles: true, cancelable: true, view: window }));
      trigger.click();
    } catch (_) {}
    await sleep(450);

    let option = chooseBestVisibleOption();

    // Editable Workday combobox: type into the underlying input so Workday's
    // own search/filter logic runs, then select the resulting option.
    if (!option) {
      const input = (el.matches('input,textarea') ? el : null) ||
        wrapper?.querySelector('input:not([type="hidden"]),textarea');
      if (input) {
        const setter = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, 'value')?.set;
        input.focus();
        if (setter) setter.call(input, '');
        input.dispatchEvent(new InputEvent('input', { bubbles: true, inputType: 'deleteContentBackward', data: null }));
        if (setter) setter.call(input, wanted);
        input.dispatchEvent(new InputEvent('input', { bubbles: true, inputType: 'insertText', data: wanted }));
        await sleep(750);
        option = chooseBestVisibleOption();
      }
    }

    if (option) {
      option.scrollIntoView({ block: 'nearest' });
      try {
        option.dispatchEvent(new MouseEvent('mousedown', { bubbles: true, cancelable: true, view: window }));
        option.click();
      } catch (_) {}
      await sleep(400);
      const current = cleanLabel(
        el.value || el.getAttribute('aria-valuetext') || el.textContent || ''
      );
      if (normalize(current) === normalize(optionText(option)) || normalize(current) === wantedNorm) {
        console.debug('[Workday Autofill] selected Workday option:', wanted, optionText(option));
        return;
      }

      // Workday may update a hidden input rather than the role=combobox node.
      // A successful option click is still preferable to flagging the field
      // when the popup has disappeared.
      if (!optionNodes().length) {
        console.debug('[Workday Autofill] option click closed the Workday popup:', wanted, optionText(option));
        return;
      }
    }

    // Keyboard fallback. This is intentionally last because synthetic
    // keyboard events are less reliable than selecting Workday's actual DOM
    // option, but it works for several native/accessible combobox variants.
    try {
      trigger.focus();
      trigger.dispatchEvent(new KeyboardEvent('keydown', { key: 'Home', bubbles: true }));
      trigger.dispatchEvent(new KeyboardEvent('keydown', { key: 'ArrowDown', bubbles: true }));
      trigger.dispatchEvent(new KeyboardEvent('keydown', { key: 'Enter', bubbles: true }));
      await sleep(300);
    } catch (_) {}

    const currentText = cleanLabel(el.value || el.getAttribute('aria-valuetext') || el.textContent || '');
    if (normalize(currentText) !== wantedNorm && !normalize(currentText).includes(wantedNorm)) {
      flagForManualEntry(field, wanted);
      console.warn('[Workday Autofill] could not select Workday option:', wanted, { currentText });
    }
  }

  async function typeIntoField(el, value) {
    const normalized = String(value).trim();
    if (!normalized) return;

    el.scrollIntoView({ block: "center", behavior: "instant" });
    await ensurePageBridge();

    // Give the page-world bridge a stable handle to this exact DOM node.
    const bridgeId = `wf-${Date.now()}-${Math.random().toString(36).slice(2)}`;
    el.setAttribute("data-wf-autofill-id", bridgeId);

    let resultReceived = false;
    const resultPromise = new Promise(resolve => {
      const handler = (event) => {
        if (event.source !== window) return;
        const data = event.data;
        if (!data || data.source !== "WF_AUTOFILL_PAGE" ||
            data.type !== "WF_SET_REACT_VALUE_RESULT" || data.id !== bridgeId) return;
        window.removeEventListener("message", handler);
        resultReceived = true;
        resolve(!!data.ok);
      };
      window.addEventListener("message", handler);
      setTimeout(() => {
        window.removeEventListener("message", handler);
        resolve(false);
      }, 1800);
    });

    window.postMessage({
      source: "WF_AUTOFILL_CONTENT",
      type: "WF_SET_REACT_VALUE",
      id: bridgeId,
      value: normalized
    }, "*");

    const bridgeOk = await resultPromise;
    el.removeAttribute("data-wf-autofill-id");

    // Always perform a local commit too. This covers a tenant where the page
    // bridge is delayed/blocked and also makes the field visibly behave like a
    // normal focused -> edited -> blurred Workday control.
    if (!bridgeOk) {
      const tag = el.tagName.toUpperCase();
      const proto = tag === "TEXTAREA"
        ? window.HTMLTextAreaElement.prototype
        : window.HTMLInputElement.prototype;
      const setter = Object.getOwnPropertyDescriptor(proto, "value")?.set;
      if (!setter) throw new Error(`No native value setter for ${tag}`);
      try { el.focus(); } catch (_) {}
      try { el._valueTracker?.setValue?.(String(el.value || "")); } catch (_) {}
      setter.call(el, normalized);
      el.dispatchEvent(new InputEvent("input", {
        bubbles: true, inputType: "insertText", data: normalized
      }));
      el.dispatchEvent(new Event("change", { bubbles: true }));
      el.dispatchEvent(new FocusEvent("focusout", { bubbles: true }));
      try { el.blur(); } catch (_) {}
    }

    await sleep(120);

    if (String(el.value || "").trim() !== normalized) {
      throw new Error(`Workday field did not retain value: ${normalized}`);
    }

    console.debug("[Workday Autofill] React text committed:", getControlLabel(el), normalized, { bridgeOk, resultReceived });
  }

  function selectOption(selectEl, value) {
    const wanted = value.trim().toLowerCase();
    const option = Array.from(selectEl.options).find(o =>
      o.textContent.trim().toLowerCase() === wanted ||
      o.value.trim().toLowerCase() === wanted
    );

    if (!option) {
      flagForManualEntry(
        { label: getControlLabel(selectEl) },
        value
      );
      return;
    }

    const setter = Object.getOwnPropertyDescriptor(
      window.HTMLSelectElement.prototype, "value"
    )?.set;

    if (!setter) throw new Error("No native select value setter");

    selectEl.focus();
    setter.call(selectEl, option.value);
    selectEl.dispatchEvent(new Event("input", { bubbles: true }));
    selectEl.dispatchEvent(new Event("change", { bubbles: true }));
    selectEl.blur();
  }

  function selectChoice(wrapper, value) {
    if (!wrapper) return;
    const wanted = value.trim().toLowerCase();
    const inputs = wrapper.querySelectorAll('input[type="radio"], input[type="checkbox"]');

    // For a single checkbox such as "I currently work here", Yes/No is a
    // semantic answer, not the visible label text.
    if (inputs.length === 1 && inputs[0].type === "checkbox" &&
        (wanted === "yes" || wanted === "no" || wanted === "true" || wanted === "false")) {
      const shouldBeChecked = wanted === "yes" || wanted === "true";
      if (inputs[0].checked !== shouldBeChecked) inputs[0].click();
      return;
    }

    for (const input of inputs) {
      const lbl = input.id
        ? document.querySelector(`label[for="${CSS.escape(input.id)}"]`)
        : null;
      const text = (lbl?.textContent || input.value || "").trim().toLowerCase();

      if (text === wanted || text.includes(wanted) || wanted.includes(text)) {
        input.click();
        return;
      }
    }

    flagForManualEntry(
      { label: getControlLabel(wrapper) },
      value
    );
  }

  function getControlLabel(el) {
    const wrapper =
      el.closest('[data-automation-id^="formField-"]') ||
      el.closest("fieldset") ||
      el.parentElement;
    return extractLabelForControl(el, wrapper) || "Unknown field";
  }

  // ============================================================
  // Utilities
  // ============================================================
  function isVisible(el) {
    const rect = el.getBoundingClientRect();
    return rect.width > 0 && rect.height > 0 && window.getComputedStyle(el).visibility !== "hidden";
  }

  function sleep(ms) {
    return new Promise((resolve) => setTimeout(resolve, ms));
  }

  function waitForStableDom(quietMs = 700, timeoutMs = 8000) {
    return new Promise((resolve) => {
      if (!document.body) {
        setTimeout(() => resolve(), 300);
        return;
      }
      let timer = setTimeout(finish, quietMs);
      const observer = new MutationObserver(() => {
        clearTimeout(timer);
        timer = setTimeout(finish, quietMs);
      });
      observer.observe(document.body, { childList: true, subtree: true });
      const hardStop = setTimeout(finish, timeoutMs);
      function finish() {
        clearTimeout(timer);
        clearTimeout(hardStop);
        observer.disconnect();
        resolve();
      }
    });
  }

  function toast(message, kind) {
    let el = document.getElementById("wf-autofill-toast");
    if (!el) {
      el = document.createElement("div");
      el.id = "wf-autofill-toast";
      document.body.appendChild(el);
    }
    el.textContent = message;
    el.className = kind || "info";
    el.style.opacity = "1";
    clearTimeout(toast._t);
    toast._t = setTimeout(() => (el.style.opacity = "0"), 4000);
  }
})();
